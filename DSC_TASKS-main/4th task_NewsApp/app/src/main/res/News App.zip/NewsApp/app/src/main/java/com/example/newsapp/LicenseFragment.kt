package com.example.newsapp

import androidx.fragment.app.Fragment

class LicenseFragment : Fragment(R.layout.fragment_license){



}