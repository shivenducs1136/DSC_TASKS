package com.example.newsapp.api

data class Source(
    val id: String,
    val name: String
)